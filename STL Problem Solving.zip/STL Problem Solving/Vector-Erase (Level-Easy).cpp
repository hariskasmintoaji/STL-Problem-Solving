#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
   int N;
   int x,a,b; 
    vector<int>v;
    cin >> N; 
    int tmp;
    //cout << N << endl;
           for(int i=0;i<N;i++)
           {
              cin >> tmp;
              v.push_back(tmp);
           //   cout << v[i] << " ";
             // cout << v.size() << " ";
           }
  //  cout << endl;       
    cin >> x;
  //  cout << x << endl;
    cin >> a >> b;
  //  cout << a << " ";
  //  cout << b;         
     v.erase(v.begin()+x-1);
     v.erase(v.begin()+a-1,v.begin()+b-1);          
    cout << v.size() << endl;
    for(int i=0;i<v.size()-1;i++)
    {
        cout << v[i] << " ";
    }
    cout << v[v.size()-1];
    return 0;
}
