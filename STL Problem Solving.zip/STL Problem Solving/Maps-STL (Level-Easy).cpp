#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <set>
#include <map>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
int N;
int type_Q;
string X;
int Y;
map<string,int>m;

cin >> N;
for(int i=0;i<N;i++)
{
    cin >> type_Q;
    if(type_Q == 1)
    { 
    cin >> X >> Y;
  pair<map<string,int>::iterator,bool> ret;
  ret = m.insert (make_pair(X,Y));
  if (ret.second==false) {
 //   cout << "'X' already existed with a value of "<< ret.first->second << '\n';
    ret.first->second +=Y; 
  }
  
    
    }
    else if(type_Q == 2) 
    {
    cin >> X;
    //   cout << type_Q << " " << X << " " << endl; 
    m.erase(X); 
    }
    else 
    {
    cin >> X;
    map<string,int>::iterator itr=m.find(X),itr2=m.end();
        if(itr != itr2)
        {
        cout << itr->second << endl;
        }
        else 
        {
        cout << 0 <<endl;
        }
    }

}      
    map<string,int>::iterator it;
    for (it=m.begin(); it!=m.end(); ++it)
    {
  //  cout << it->first << " => " << it->second << '\n';
    }
       
    return 0;

}