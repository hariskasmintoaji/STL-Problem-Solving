#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <set>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
 int N; //jumlah query;
 int x,y;
 set<int>s; //set
 cin >> N;
 for(int i=0;i<N;i++)
 {
     cin >> y >> x;
 //    cout << y << " " << x << endl;
 if(y==1)
 {
     s.insert(x);
 }
 else if(y==2)
 {
     s.erase(x);
  //cout << s.erase(1000) << endl;
 }
 else
 {
    set<int>::iterator itr=s.find(x),itr2=s.end();
    if(itr != itr2)
    {
        cout << "Yes" << endl;
    }  
    else
    {
        cout << "No"  << endl;
    }
 }
 
 //set<int>::iterator itr=s.find(x);
 //cout << *itr << endl;
 // set<int>::iterator itr2=s.end();
// cout << *itr2 << endl; 
 
     
 }
    
    
       
    return 0;
}