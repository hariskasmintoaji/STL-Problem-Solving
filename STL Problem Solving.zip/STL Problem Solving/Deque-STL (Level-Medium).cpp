#include <iostream>
#include <deque> 
using namespace std;

void printKMax(int arr[], int n, int k){
    //Write your code here.
    deque<int> mydeque;
    deque<int> max_deq;
    int tmp_max=arr[0];
for(int i=0;i<k;i++)
{
    mydeque.push_back(arr[i]); //initial collection
    if(tmp_max < arr[i])
    {
        tmp_max=arr[i];
    } 
}
max_deq.push_back(tmp_max);

    
    for(int i=k;i<n;i++)
    {
        
        deque<int>::iterator it = mydeque.begin();
        int tmp = *it; //for compare
        mydeque.pop_front();
        mydeque.push_back(arr[i]);
        if(tmp != tmp_max)
        {
            if( tmp_max < arr[i])
            {
                tmp_max = arr[i];
                max_deq.push_back(tmp_max);
            }
            else
            {
                max_deq.push_back(tmp_max);
            }
        }
        else
        {
            tmp_max=0;
            for(int j=0;j<k;j++)
            {
              
                if(tmp_max < mydeque[j])
                {
                tmp_max=mydeque[j];
                } 
            }
             max_deq.push_back(tmp_max);  
        }
    }
 for(deque<int>::iterator it = max_deq.begin(); it != max_deq.end();++it)
 {
    cout << *it << " "; 
 }
    cout << '\n';
}

int main(){
  
    int t;
    cin >> t;
    while(t>0) {
        int n,k;
        cin >> n >> k;
        int i;
        int arr[n];
        for(int i=0;i<n;i++)
              cin >> arr[i];
        printKMax(arr, n, k);
        t--;
      }
      return 0;
}